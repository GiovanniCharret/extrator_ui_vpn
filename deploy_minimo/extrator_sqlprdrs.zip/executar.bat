@echo off
REM ====================================================================
REM  Atualizacao das bases - Luz para Todos (Fase 2: UCs/ODIs via SQL-SSRS)
REM  COMO USAR: de dois cliques neste arquivo e aguarde terminar.
REM  Ele SEMPRE faz o refresh completo (baixa todos os contratos do ucs_map).
REM  Na 1a vez, instala sozinho o 'uv' (pode demorar um pouco a mais).
REM  Nao edite este arquivo.
REM ====================================================================
title Atualizacao das bases - Luz para Todos
cd /d "%~dp0"

REM  O "2" seleciona a Fase 2 (UCs via SSRS). A Fase 1 (scraping do LNC) foi
REM  aposentada em 17/09/2026 - ODIs e UCs vem todas do SQL/SSRS.
powershell -ExecutionPolicy Bypass -File "run_tudo_com_uv_install.ps1" 2 --refresh
set CODIGO=%ERRORLEVEL%

echo.
echo ====================================================================
if "%CODIGO%"=="0" (
  echo  CONCLUIDO COM SUCESSO. Pode fechar esta janela.
) else (
  echo  ATENCAO: ocorreu um erro ^(codigo %CODIGO%^).
  echo  Tire um print desta tela e avise o responsavel.
)
echo ====================================================================
echo.
pause
