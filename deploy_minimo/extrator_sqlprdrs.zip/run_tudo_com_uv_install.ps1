# run_tudo_com_uv_install.ps1 - ponto de entrada dos administradores (chamado pelo run_tudo.bat).
# Existe para uma maquina de producao SEM o 'uv' instalado: garante o 'uv' (instalando-o
# na 1a vez) e entao delega ao run_tudo.ps1, que orquestra as duas fases. Os scripts de fase
# (run.ps1 / run_ucs.ps1) exigem o 'uv' como pre-requisito; aqui ele passa a existir antes deles.
# Uso: identico ao run_tudo.ps1 (os argumentos sao repassados). O .bat chama com --refresh.
$ErrorActionPreference = "Stop"
$raiz = Split-Path -Parent $MyInvocation.MyCommand.Path

# 1) Garante o 'uv'. Se ausente, instala pelo instalador oficial (a VPN tem internet).
if (-not (Get-Command uv -ErrorAction SilentlyContinue)) {
    Write-Host "uv nao encontrado - instalando (astral.sh)..."
    # Fixa o diretorio de destino num caminho conhecido, para adiciona-lo ao PATH abaixo.
    $env:UV_INSTALL_DIR = Join-Path $env:USERPROFILE ".local\bin"
    try {
        Invoke-RestMethod https://astral.sh/uv/install.ps1 | Invoke-Expression
    } catch {
        Write-Error "falha ao instalar o uv: $($_.Exception.Message)"
        exit 1
    }
    # SUTILEZA: o instalador so ajusta o PATH do usuario no registro - o processo atual
    # nao ve. Injeta-se o destino no PATH desta sessao para o 'uv' valer JA nesta rodada
    # (o run_tudo e as fases rodam no mesmo processo e herdam este PATH).
    $env:PATH = "$env:UV_INSTALL_DIR;$env:PATH"
    if (-not (Get-Command uv -ErrorAction SilentlyContinue)) {
        Write-Error "uv instalado mas ausente no PATH ($env:UV_INSTALL_DIR). Reabra o terminal e rode de novo."
        exit 1
    }
    Write-Host "uv instalado com sucesso."
}

# 2) Delega ao orquestrador das duas fases, repassando todos os argumentos (ex.: --refresh).
#    run_tudo e as fases rodam neste mesmo processo e herdam o PATH ajustado acima.
& (Join-Path $raiz "run_tudo.ps1") @args
exit $LASTEXITCODE
