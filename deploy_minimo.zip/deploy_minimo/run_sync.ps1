# run_sync.ps1 - envia os consolidados da rodada diaria para o site (VPS Hostinger).
# Vive em deploy_minimo\ (pasta de uso diario), ao lado do run_tudo.
#
# SO RODA NO DEV (nunca na VPN): precisa da chave SSH (~\.ssh\id_ed25519) e da
# pasta Downloads locais - na VPN ele nao tem funcao (se for junto no zip, ignore).
# Momento de uso: depois que voce baixou do Google Drive os 2 CSVs soltos para a
# pasta Downloads. Fluxo (decidido em 09/07/2026, ver
# planning/2026-07-08-atualizacao-diaria-entrada-site.md):
#
#   Downloads\consolidado.csv      -> /opt/anexov/entrada/lpt/consolidado.csv
#   Downloads\consolidado_ucs.csv  -> /opt/anexov/entrada/lpt/consolidado_ucs.csv
#
# Transporte: scp/ssh como usuario 'deploy' (chave ~\.ssh\id_ed25519), com envio
# para nome temporario (.new) + rename atomico no VPS - o backend recarrega por
# mtime e nunca pode ler um arquivo pela metade. So toca em /opt/anexov/entrada/.
# entrada/mla/ e base_contratos.json ficam FORA deste sync (decisao do usuario).
#
# Sanidade ANTES de enviar (aborta em vez de subir base quebrada):
#   - arquivo existe e nao esta vazio;
#   - primeira linha e um cabecalho plausivel (contem ';');
#   - se o numero de linhas cair mais de 20% vs o ultimo envio, aborta e avisa
#     (rodada parcial e o modo de falha tipico). Contagens do ultimo envio em
#     deploy_minimo\estado_sync.json (nao versionado).
#
# Uso:
#   .\run_sync.ps1              (envia de verdade)
#   .\run_sync.ps1 -DryRun      (so a sanidade; nao toca o VPS)
#   .\run_sync.ps1 -Origem "C:\outra\pasta"   (fonte alternativa; default Downloads)
#
# Idempotente: rodar 2x no mesmo dia so re-envia os mesmos dados (inofensivo).
# Log completo em deploy_minimo\output\logs\sync_<ts>.log (execucao cega: tudo em arquivo).
param(
    [switch]$DryRun,                                        # so valida; nao envia
    [string]$Origem = (Join-Path $env:USERPROFILE "Downloads")  # pasta dos CSVs baixados
)
$ErrorActionPreference = "Stop"

# --- Configuracao (centralizada aqui; nada espalhado pelo corpo) -------------
$VpsHost  = "gerenciador-gclt.com"                 # IP fallback (se o DNS falhar): 82.25.68.143
$VpsUser  = "deploy"                               # dono de /opt/anexov (nunca root)
$Chave    = Join-Path $env:USERPROFILE ".ssh\id_ed25519"   # chave criada em 09/07/2026
$DestDir  = "/opt/anexov/entrada/lpt"              # UNICO diretorio tocado no VPS
$QuedaMax = 0.20                                   # queda de linhas tolerada vs ultimo envio
# Mapa origem -> destino: nome do arquivo em Downloads => nome final no VPS.
$Arquivos = @(
    @{ nome = "consolidado.csv" },                # Fase 1 (contratos LPT)
    @{ nome = "consolidado_ucs.csv" }             # Fase 2 (UCs dos contratos LPT)
)

# --- Log (console + arquivo; execucao cega) ----------------------------------
$raiz = Split-Path -Parent $MyInvocation.MyCommand.Path     # raiz = pasta deste script
$logDir = Join-Path $raiz "output\logs"                     # mesmo lugar dos logs das rodadas
New-Item -ItemType Directory -Force $logDir | Out-Null      # garante a pasta
$ts = Get-Date -Format "yyyyMMdd_HHmmss"                    # carimbo desta execucao
$logFile = Join-Path $logDir "sync_$ts.log"                 # 1 log por execucao
function Log([string]$msg) {                                # toda mensagem vai p/ console E arquivo
    $linha = "{0} {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $msg
    Write-Host $linha
    Add-Content -Path $logFile -Value $linha -Encoding UTF8
}
function Falhar([string]$msg) {                             # falha SEMPRE explicita e logada
    Log ("ERRO: " + $msg)
    Log "=== SYNC ABORTADO (nada foi enviado ao VPS alem do ja concluido acima) ==="
    exit 1
}

Log "=== run_sync (DryRun=$DryRun) origem=$Origem destino=${VpsUser}@${VpsHost}:$DestDir ==="

# --- Fase 1: pre-requisitos locais (falha cedo, antes de tocar a rede) -------
if (-not (Test-Path $Chave)) { Falhar "chave SSH nao encontrada: $Chave (gerar com ssh-keygen; ver planning/2026-07-08-...md)" }
$estadoPath = Join-Path $raiz "estado_sync.json"            # contagens do ultimo envio
$estadoAnt = @{}                                            # default: primeiro envio
if (Test-Path $estadoPath) {                                # carrega o estado anterior, se houver
    try {
        $json = Get-Content $estadoPath -Raw | ConvertFrom-Json
        foreach ($p in $json.PSObject.Properties) { $estadoAnt[$p.Name] = $p.Value }
    } catch { Log "AVISO: estado_sync.json ilegivel (seguindo como primeiro envio): $($_.Exception.Message)" }
}

# --- Fase 2: sanidade de CADA arquivo (tudo validado ANTES de enviar qualquer um)
$aEnviar = @()                                              # so entra aqui quem passou em tudo
foreach ($a in $Arquivos) {
    $nome = $a.nome
    $caminho = Join-Path $Origem $nome
    # 2a. existe? (dica p/ o caso classico do navegador renomear 'arquivo (1).csv')
    if (-not (Test-Path $caminho)) {
        $parecidos = @(Get-ChildItem -Path $Origem -Filter ($nome -replace "\.csv$", "*.csv") -ErrorAction SilentlyContinue)
        $dica = ""
        if ($parecidos.Count -gt 0) { $dica = " (achei parecido(s): $($parecidos.Name -join ', ') - o navegador renomeou? renomeie de volta)" }
        Falhar "arquivo nao encontrado: $caminho$dica"
    }
    # 2b. nao-vazio?
    $tam = (Get-Item $caminho).Length
    if ($tam -eq 0) { Falhar "arquivo vazio: $caminho" }
    # 2c. cabecalho plausivel? (primeira linha precisa conter ';' - separador do projeto)
    $reader = New-Object System.IO.StreamReader($caminho)
    $cabecalho = $reader.ReadLine()
    $reader.Close()
    if ($null -eq $cabecalho -or -not $cabecalho.Contains(";")) { Falhar "cabecalho invalido em ${nome}: primeira linha sem ';' -> '$cabecalho'" }
    # 2d. contagem de linhas (rapida via ReadLines; inclui o cabecalho)
    $linhas = 0
    foreach ($l in [System.IO.File]::ReadLines($caminho)) { $linhas++ }
    # 2e. queda >20% vs ultimo envio? (rodada parcial = modo de falha tipico)
    $ant = $null
    if ($estadoAnt.ContainsKey($nome)) { $ant = [int]$estadoAnt[$nome].linhas }
    if ($null -ne $ant -and $ant -gt 0 -and $linhas -lt ($ant * (1 - $QuedaMax))) {
        Falhar ("queda de linhas suspeita em ${nome}: {0} -> {1} (mais de {2:P0}); rodada parcial? Se a queda for legitima, apague estado_sync.json e rode de novo." -f $ant, $linhas, $QuedaMax)
    }
    Log ("OK sanidade: {0} ({1} bytes, {2} linhas; ultimo envio: {3})" -f $nome, $tam, $linhas, $(if ($null -ne $ant) { $ant } else { "n/a" }))
    $aEnviar += @{ nome = $nome; caminho = $caminho; linhas = $linhas }
}

if ($DryRun) {                                              # dry-run para aqui: nada de rede
    Log "=== DRY-RUN OK: $($aEnviar.Count) arquivo(s) passariam; nada foi enviado ==="
    exit 0
}

# --- Fase 3: envio (scp para .new; nada substituido ainda) --------------------
# BatchMode: falha em vez de pedir senha (uso nao interativo); -q sem barra de progresso.
$sshOpts = @("-i", $Chave, "-o", "BatchMode=yes", "-o", "ConnectTimeout=15")
foreach ($e in $aEnviar) {
    $destNew = "$DestDir/$($e.nome).new"                    # nome temporario no VPS
    Log "enviando $($e.nome) -> ${VpsHost}:$destNew ..."
    scp -q @sshOpts $e.caminho "${VpsUser}@${VpsHost}:$destNew"
    if ($LASTEXITCODE -ne 0) { Falhar "scp falhou para $($e.nome) (codigo $LASTEXITCODE)" }
}

# --- Fase 4: rename atomico dos DOIS num unico ssh (janela minima de inconsistencia)
$mvs = @()
foreach ($e in $aEnviar) { $mvs += "mv $DestDir/$($e.nome).new $DestDir/$($e.nome)" }
$cmd = $mvs -join " && "                                    # 2o mv so roda se o 1o funcionou
Log "aplicando no VPS: $cmd"
ssh @sshOpts "${VpsUser}@${VpsHost}" $cmd
if ($LASTEXITCODE -ne 0) { Falhar "rename no VPS falhou (codigo $LASTEXITCODE) - pode ter sobrado .new em $DestDir" }
Log "arquivos substituidos no VPS (backend recarrega sozinho pelo mtime)"

# --- Fase 5: grava o estado do envio (base da checagem de queda do proximo) ---
$estadoNovo = @{}
foreach ($e in $aEnviar) {
    $estadoNovo[$e.nome] = @{ linhas = $e.linhas; enviado_em = (Get-Date -Format "s") }
}
$estadoNovo | ConvertTo-Json | Out-File -FilePath $estadoPath -Encoding utf8
Log "estado gravado: $estadoPath"

# --- Fase 6: verificacao fim a fim (best-effort; nao derruba um envio ja feito)
try {
    $health = Invoke-RestMethod "https://gerenciador-gclt.com/api/health" -TimeoutSec 30
    Log ("api/health: " + ($health | ConvertTo-Json -Compress -Depth 5))
} catch {
    Log "AVISO: api/health inacessivel (o envio em si foi concluido): $($_.Exception.Message)"
}

Log "=== SYNC OK: $($aEnviar.Count) arquivo(s) enviados ==="
exit 0
